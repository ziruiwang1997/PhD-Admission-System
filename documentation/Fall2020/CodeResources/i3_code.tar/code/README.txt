1. put "credentials.json" and "quickstart.py" in the same directory
2. pip install --upgrade google-api-python-client google-auth-httplib2 google-auth-oauthlib
3. python demo_google_drive.py or demo_google_sheet.py
4. for 1st time login, an authentication page will be prompted, fill in your google account and password
5. I created a google account for testing
	account:  aihua.xu123
	password: !jjj123456
6. test sheet url: https://docs.google.com/spreadsheets/d/1yV7XHAy17Isg5boaf2tEvzpqcKdr9-m-sqYt2CsPeNs/edit#gid=0

!!! whenever modify the google_drive_access_scopes in config.json, (for testing, there is no need to change the scopes now), for example, modify the access allowed to google drive or google sheet,
should delete the cached_auth_file, in order to update the permissions.
