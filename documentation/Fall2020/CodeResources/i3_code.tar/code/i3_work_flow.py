from constants import (
    LOCAL_RAW_PDF_DIR,
    LOCAL_PROCESSED_TXT_DIR,
    DRIVE_RAW_PDF_DIR, 
    DRIVE_PROCESSED_TXT_DIR,
    DRIVE_FOLDER_ID_DICT,
    LOG_FILE_NAME,
    APPLICANTS_INFO_FILE_NAME
)
import os
from pprint import pprint
import random
import datetime
import time
from utils import (
    GoogleServiceConnector,
    get_google_drive_service,
    get_google_sheet_service,
    demo_download_file_from_google_drive,
    demo_upload_file_to_google_drive,
    demo_update_google_sheet,
    get_values_in_google_sheet,
    get_filename,
    get_google_sheet_rows,
    update_existing_data_google_sheet,
    send_email
)

class NewAutoRunner:
    pdf_folder_id = DRIVE_FOLDER_ID_DICT[DRIVE_RAW_PDF_DIR]
    txt_folder_id = DRIVE_FOLDER_ID_DICT[DRIVE_PROCESSED_TXT_DIR]
    local_log_file_path = os.path.join(LOCAL_RAW_PDF_DIR, LOG_FILE_NAME)
    local_applicants_info_file_path = os.path.join(LOCAL_PROCESSED_TXT_DIR, APPLICANTS_INFO_FILE_NAME)
    
    @staticmethod
    def create_directory(directory):
        if not os.path.exists(directory):
        	os.mkdir(directory)
    
    @staticmethod
    def create_file(file_path):
        with open(file_path, "w") as f:
            pass
    
    def __init__(self):
        self.create_directory(LOCAL_PROCESSED_TXT_DIR)
        self.create_directory(LOCAL_RAW_PDF_DIR)
        conn = GoogleServiceConnector()
        conn.connect()
        self.drive_service = get_google_drive_service(conn)
        self.sheet_service = get_google_sheet_service(conn)
        self.sheet_rows = get_google_sheet_rows(self.sheet_service) - 1
        self.existing_applicants = self.get_existing_applicants(self.sheet_service)
        self.append_files = set()
        self.update_files = set()
        self.append_applicants_id = set()
        self.update_applicants_id = set()

    def load_google_drive_items(self):
        """
        Step1: Scan the raw_pdf directory in google drive, check whether there are new pdfs
            the 'log.txt' file in the directory contains processed pdfs, we only need to download 
            those files not listed in 'log.txt'.
        """
        results = self.drive_service.files().list(q=f"'{self.pdf_folder_id}' in parents and trashed=false", fields="nextPageToken, files(id, name, version)").execute()
        self.pdf_dir_items = results.get("files", [])
        results = self.drive_service.files().list(q=f"'{self.txt_folder_id}' in parents and trashed=false", fields="nextPageToken, files(id, name)").execute()
        self.txt_dir_items = results.get("files", [])
        
    def download_logfile_and_infofile(self):
        self.log_file_id = None
        self.applicants_info_file_id = None
        for item in self.pdf_dir_items:
            if item["name"].endswith(LOG_FILE_NAME):
                self.log_file_id = item["id"]
                demo_download_file_from_google_drive(self.drive_service, {self.local_log_file_path : self.log_file_id})
                break
        if self.log_file_id is None:
            self.create_file(self.local_log_file_path)
        
        for item in self.txt_dir_items:
            if item["name"].endswith(APPLICANTS_INFO_FILE_NAME):
                self.applicants_info_file_id = item["id"]
                demo_download_file_from_google_drive(self.drive_service, {self.local_applicants_info_file_path : self.applicants_info_file_id})
                break
        if self.applicants_info_file_id is None:
            self.create_file(self.local_applicants_info_file_path)
    
    def download_new_pdfs(self):
        """
        Step2: Download those new pdfs and the log file
            Store them in the local raw_pdf directory 
        """
        # download pdfs
        self.name_id_dict = dict()
        self.name_version_dict = dict()
        processed_names = dict()
        with open(self.local_log_file_path, "r") as f:
            for line in f:
                [name, version] = line.split(',')
                version = int(version)
                processed_names[name] = version
        with open(self.local_log_file_path, "a") as f:
            for item in self.pdf_dir_items:
                name = item["name"]
                version = int(item["version"])
                if name.endswith(".pdf") and (name not in processed_names or processed_names[name] != version):
                    self.name_version_dict[name] = version
                    whole_path = os.path.join(LOCAL_RAW_PDF_DIR, name)
                    self.name_id_dict[whole_path] = item["id"]
                    f.write(f"{name},{version}\n")
                    if name not in processed_names:
                        self.append_files.add(whole_path)
                    elif processed_names[name] != version:
                        while True:
                            sure = input(f"{name} has been updated, do you want to update the corresponding info in google sheet? (y/n): ")
                            if sure:
                                sure = sure.lower()
                                if sure[0] == 'y':
                                    self.update_files.add(whole_path)
                                    break
                                elif sure[0] == 'n':
                                    break
        if self.update_files:
            print(f"Updated files: {self.update_files}")
        if self.append_files:
            print(f"New files: {self.append_files}")
        if self.name_id_dict:
            demo_download_file_from_google_drive(self.drive_service, self.name_id_dict)
    
    @staticmethod
    def test_parser(sheet_rows, file_path, applicant_id=None):
        degrees = ["MS", "PHD", "BS"]
        nationalities = ["USA", "UK", "CHINA", "INDIA", "JAPAN", "CANADA"]
        names = ["Jack", "Tom", "Micheal", "Jackson", "Tommy", "Allen", "James"]
        interests = ["SE", "AI", "DL", "ME", "ECON", "FINTECH", "MATH", "PHYSICS"]
        genders = ['F', 'M']
        potential_faculties = ["Professor NO.1", "Professor NO.2", "Professor NO.3", "Professor NO.4"]
        if applicant_id is None:
            file_name = get_filename(file_path)[:-4]
            applicant_id = file_name
        name = random.choice(names) + ", " + random.choice(names)
        degree = random.choice(degrees)
        nationality = random.choice(nationalities)
        interest = random.choice(interests)
        bs_gpa = random.uniform(1, 5)
        ms_gpa = random.uniform(1, 5)
        gre = random.randint(320, 340)
        toefl = random.randint(100, 120)
        gender = random.choice(genders)
        applicant_gpa = random.uniform(0, 5)
        potential_faculty = random.choice(potential_faculties)
        return [sheet_rows, applicant_id, "=AVERAGEIF(Reviews!A:A,\"=" + applicant_id + "\", Reviews!C:C)", 
                "=COUNTIF(Reviews!A:A,\"=" + applicant_id + "\")", degree, nationality, name, 
                interest, potential_faculty, bs_gpa, ms_gpa, gre, toefl, gender, None, None, None]
        
    def parse_new_pdfs(self):
        """
        Step3: Parse the new pdfs and store the new information to the processed_txt
            Update the info txt file, this file contains all phd info, just like a google sheet
        """
        if not self.name_id_dict:
            return
        self.new_data = []
        self.old_data = []
        self.processed_txt_file_paths = []
        for file_path in self.name_id_dict:
            file_name = get_filename(file_path)
            new_file_path = os.path.join(LOCAL_PROCESSED_TXT_DIR, file_name[:-4]) + "_v{}.txt".format(self.name_version_dict[file_name])
            self.processed_txt_file_paths.append(new_file_path)
            if file_path in self.append_files:
                self.sheet_rows += 1
                temp_row = self.test_parser(self.sheet_rows, file_path)
                self.new_data.append(temp_row)
                self.append_applicants_id.add(temp_row[1])
                temp_row = temp_row[:]
                temp_row[0] = f"version{self.name_version_dict[get_filename(file_path)]}" 
                new_line = ";".join([str(_) for _ in temp_row])
            else:
                temp_row = self.test_parser(self.sheet_rows, file_path)
                self.old_data.append(temp_row)
                self.append_applicants_id.add(temp_row[1])
                temp_row = temp_row[:]
                temp_row[0] = f"version{self.name_version_dict[get_filename(file_path)]}"
                new_line = ";".join([str(_) for _ in temp_row])
            new_line += "\n"
            with open(new_file_path, "w") as f:
                f.write(new_line)
            with open(self.local_applicants_info_file_path, "a") as f:
                f.write(new_line)
        
    def upload_logfile_and_infofile(self):
        """
        Step4: Delete the old log file and  upload the new log file to the google drive.
        """
        if not self.name_id_dict:
            return
        print("log_file_id is {0}".format(self.log_file_id))
        if self.log_file_id is not None:
            self.drive_service.files().delete(fileId=self.log_file_id).execute()
        demo_upload_file_to_google_drive(self.drive_service, file_paths=[self.local_log_file_path], folder_id=self.pdf_folder_id)
        
        print("info_file_id is {0}".format(self.applicants_info_file_id))
        if self.applicants_info_file_id is not None:
            self.drive_service.files().delete(fileId=self.applicants_info_file_id).execute()
        demo_upload_file_to_google_drive(self.drive_service, file_paths=[self.local_applicants_info_file_path], folder_id=self.txt_folder_id)
        """
        Step5: Upload the new processed txts to google drive for backup
        """
        demo_upload_file_to_google_drive(self.drive_service, file_paths=self.processed_txt_file_paths, folder_id=self.txt_folder_id)
    
    def update_google_sheet(self):
        """
        Step6: Update the new info to the google sheet
        """
        if not self.name_id_dict:
            return
        demo_update_google_sheet(self.sheet_service, data_list=self.new_data)
    
    # info_dict: {'id_01': {'name' : 'jack'}, 'id_02' : {'degree' : 'phd'}}
    def update_existing_applicant_info(self):
        values = get_values_in_google_sheet(self.sheet_service)
        for new_value in self.old_data:
            for idx, old_value in enumerate(values):
                if new_value[1] == old_value[1]:
                    print(f"exisiting applicant_id: {new_value[1]}")
                    update_existing_data_google_sheet(self.sheet_service, sheet_range="E{0}:N{0}".format(idx+1), data=[new_value[4:14]])
                    break
                
    @staticmethod
    def get_existing_applicants(service):
        values = get_values_in_google_sheet(service)
        for idx, val in enumerate(values[0]):
            if (val == "Application ID"):
                break
        existing_applicants = set()
        [existing_applicants.add(_[idx]) for _ in values[1:]]
        return existing_applicants
            
    def run(self):
        self.load_google_drive_items()
        self.download_logfile_and_infofile()
        self.download_new_pdfs()
        if self.name_id_dict:
            self.parse_new_pdfs()
            self.upload_logfile_and_infofile()
            self.update_existing_applicant_info()
            subject = "PhD Admin: Existing Applicants' information has been updated!"
            content = "Dear Professor,\nThe following applicants' information has been updated:\n{}".format(self.update_applicants_id)
            send_email(subject=subject, content=content)
            self.update_google_sheet()
            subject = "PhD Admin: New Applicants have been added!"
            content = "Dear Professor,\nThe following applicants have been added:\n{}".format(self.append_applicants_id)
            send_email(subject=subject, content=content)
        
        else:
            print(f"{datetime.datetime.now()}: No new pdfs")
        
if __name__ == "__main__":
    NewAutoRunner().run()
        