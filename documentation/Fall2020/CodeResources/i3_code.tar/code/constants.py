CONFIG = "config.json"

LOCAL_RAW_PDF_DIR = "raw_pdf"
LOCAL_PROCESSED_TXT_DIR = "processed_txt"

DRIVE_RAW_PDF_DIR = "raw_pdf"
DRIVE_PROCESSED_TXT_DIR = "processed_txt"

DRIVE_FOLDER_ID_DICT = {
    DRIVE_RAW_PDF_DIR : "1y2-x6Uux9gJg2o2ucId6QbvW4eFfhGHC",
    DRIVE_PROCESSED_TXT_DIR : "1Srpvyh62DpNWzm3Hqa2z1lpx92SchPP9"
}

# https://docs.google.com/spreadsheets/d/1yV7XHAy17Isg5boaf2tEvzpqcKdr9-m-sqYt2CsPeNs/edit#gid=0
SHEET_ID = "1yV7XHAy17Isg5boaf2tEvzpqcKdr9-m-sqYt2CsPeNs"
SHEET_RANGE = "Sheet1!A:Q"

LOG_FILE_NAME = "log.txt"
APPLICANTS_INFO_FILE_NAME = "applicants_info.txt"

ADMIN_LIST = ["aihua.xu123@gmail.com", "jiangjinjinyxt@gmail.com"]
MAIL_HOST = "smtp.gmail.com"
MAIL_USER_NAME = "aihua.xu123@gmail.com"
MAIL_PASSWD = "!jjj123456"
