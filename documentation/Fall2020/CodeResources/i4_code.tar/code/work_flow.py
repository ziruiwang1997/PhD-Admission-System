# -*- coding: utf-8 -*-
from auto_runner import NewAutoRunner

if __name__ == "__main__":
    NewAutoRunner().run()