CONFIG = "config.json"

LOCAL_RAW_PDF_DIR = "raw_pdf"
LOCAL_PROCESSED_TXT_DIR = "processed_txt"

DRIVE_RAW_PDF_DIR = "raw_pdf"
DRIVE_PROCESSED_TXT_DIR = "processed_txt"

DRIVE_FOLDER_ID_DICT = {
    DRIVE_RAW_PDF_DIR : "raw_dir_id",
    DRIVE_PROCESSED_TXT_DIR : "processed_dir_id"
}

SHEET_ID = "sheet_id"
SHEET_RANGE = "Sheet1!A:Q"

LOG_FILE_NAME = "log.txt"
APPLICANTS_INFO_FILE_NAME = "applicants_info.txt"

ADMIN_LIST = ["receiver1@gmail.com", "receiver2@gmail.com"]
MAIL_HOST = "smtp.gmail.com"
MAIL_USER_NAME = "sender@gmail.com"
MAIL_PASSWD = "passwd"
