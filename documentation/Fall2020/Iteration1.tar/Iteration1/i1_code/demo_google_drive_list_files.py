from constants import DRIVE_RAW_PDF_DIR, DRIVE_FOLDER_ID_DICT
from utils import (
    GoogleServiceConnector,
    get_google_drive_service,
    demo_list_files_in_google_drive
)

def main():
	conn = GoogleServiceConnector()
	conn.connect()
	drive_service = get_google_drive_service(conn)
	# List files in specified folder, example: raw_pdf
	demo_list_files_in_google_drive(drive_service, folder_id=DRIVE_FOLDER_ID_DICT[DRIVE_RAW_PDF_DIR])
	
	print()
	
	# List files in the whole drive
	demo_list_files_in_google_drive(drive_service)
    
if __name__ == "__main__":
	main()