from constants import LOCAL_PROCESSED_TXT_DIR, DRIVE_PROCESSED_TXT_DIR, DRIVE_FOLDER_ID_DICT
import os
from utils import (
    GoogleServiceConnector,
    get_google_drive_service,
    demo_upload_file_to_google_drive
)


def main():
	conn = GoogleServiceConnector()
	conn.connect()
	drive_service = get_google_drive_service(conn)
	file_paths = [os.path.join(LOCAL_PROCESSED_TXT_DIR, _) for _ in os.listdir(LOCAL_PROCESSED_TXT_DIR)]
	folder_id = DRIVE_FOLDER_ID_DICT[DRIVE_PROCESSED_TXT_DIR]
	demo_upload_file_to_google_drive(drive_service, file_paths, folder_id)

if __name__ == '__main__':
    main()
