from constants import (
    LOCAL_RAW_PDF_DIR,
    LOCAL_PROCESSED_TXT_DIR,
    DRIVE_RAW_PDF_DIR,
    DRIVE_PROCESSED_TXT_DIR,
    DRIVE_FOLDER_ID_DICT,
    LOG_FILE_NAME,
    APPLICANTS_INFO_FILE_NAME
)
import os
import random
import datetime
import time
from utils import (
    GoogleServiceConnector,
    get_google_drive_service,
    get_google_sheet_service,
    demo_download_file_from_google_drive,
    demo_upload_file_to_google_drive,
    demo_update_google_sheet,
    get_filename,
    get_google_sheet_rows
)

class AutoRunner:
    pdf_folder_id = DRIVE_FOLDER_ID_DICT[DRIVE_RAW_PDF_DIR]
    txt_folder_id = DRIVE_FOLDER_ID_DICT[DRIVE_PROCESSED_TXT_DIR]
    local_log_file_path = os.path.join(LOCAL_RAW_PDF_DIR, LOG_FILE_NAME)
    local_applicants_info_file_path = os.path.join(LOCAL_PROCESSED_TXT_DIR, APPLICANTS_INFO_FILE_NAME)

    @staticmethod
    def create_directory(directory):
        if not os.path.exists(directory):
        	os.mkdir(directory)

    @staticmethod
    def create_file(file_path):
        if not os.path.exists(file_path):
            with open(file_path, "w") as f:
                pass

    def __init__(self):
        self.create_directory(LOCAL_PROCESSED_TXT_DIR)
        self.create_directory(LOCAL_RAW_PDF_DIR)
        conn = GoogleServiceConnector()
        conn.connect()
        self.drive_service = get_google_drive_service(conn)
        self.sheet_service = get_google_sheet_service(conn)
        self.sheet_rows = get_google_sheet_rows(self.sheet_service)

    def load_google_drive_items(self):
        """
        Step1: Scan the raw_pdf directory in google drive, check whether there are new pdfs
            the 'log.txt' file in the directory contains processed pdfs, we only need to download
            those files not listed in 'log.txt'.
        """
        results = self.drive_service.files().list(q=f"'{self.pdf_folder_id}' in parents", fields="nextPageToken, files(id, name)").execute()
        self.pdf_dir_items = results.get("files", [])
        results = self.drive_service.files().list(q=f"'{self.txt_folder_id}' in parents", fields="nextPageToken, files(id, name)").execute()
        self.txt_dir_items = results.get("files", [])

    def download_logfile_and_infofile(self):
        self.log_file_id = None
        self.applicants_info_file_id = None
        for item in self.pdf_dir_items:
            if item["name"].endswith(LOG_FILE_NAME):
                self.log_file_id = item["id"]
                demo_download_file_from_google_drive(self.drive_service, {self.local_log_file_path : self.log_file_id})
                break
        self.create_file(self.local_log_file_path)

        for item in self.txt_dir_items:
            if item["name"].endswith(APPLICANTS_INFO_FILE_NAME):
                self.applicants_info_file_id = item["id"]
                demo_download_file_from_google_drive(self.drive_service, {self.local_applicants_info_file_path : self.applicants_info_file_id})
                break
        self.create_file(self.local_applicants_info_file_path)

    def download_new_pdfs(self):
        """
        Step2: Download those new pdfs and the log file
            Store them in the local raw_pdf directory
        """
        # download pdfs
        self.name_id_dict = dict()
        AutoRunner.test_pdf(self.local_log_file_path)
        with open(self.local_log_file_path, "r") as f:
            processed_names = set(f.read().split("\n"))

        with open(self.local_log_file_path, "a") as f:
            for item in self.pdf_dir_items:
                name = item["name"]
                if name.endswith(".pdf") and name not in processed_names:
                    self.name_id_dict[os.path.join(LOCAL_RAW_PDF_DIR, name)] = item["id"]
                    f.write(f"{name}\n")
        if self.name_id_dict:
            demo_download_file_from_google_drive(self.drive_service, self.name_id_dict)

    @staticmethod
    def test_parser(sheet_rows, file_path):
        degrees = ["MS", "PHD", "BS"]
        nationalities = ["USA", "UK", "CHINA", "INDIA", "JAPAN", "CANADA"]
        names = ["Jack", "Tom", "Micheal", "Jackson", "Tommy", "Allen", "James"]
        interests = ["SE", "AI", "DL", "ME", "ECON", "FINTECH", "MATH", "PHYSICS"]
        genders = ['F', 'M']
        # applicant_id = random.randint(1, 10000)
        # name = random.choice(names) + ", " + random.choice(names)
        # degree = random.choice(degrees)
        # nationality = random.choice(nationalities)
        # interest = random.choice(interests)
        # bs_gpa = random.uniform(1, 5)
        # ms_gpa = random.uniform(1, 5)
        # gre = random.randint(320, 340)
        # toefl = random.randint(100, 120)
        # gender = random.choice(genders)
        # applicant_gpa = random.uniform(0, 5)
        applicant_id = [1000, 1100]
        name = ["Ryuki", "Kobayashi"]
        degree = ["MS", "PHD"]
        nationality = ["JAPAN", "CHINA"]
        interest = ["SE", "AI"]
        bs_gpa = [3.3, 3.5]
        ms_gpa = [4.0, 4.2]
        gre = [330, 340]
        toefl = [100, 110]
        gender = ["M", "F"]
        applicant_gpa = [3.5, 3.8]

        for i in range(2):
            output = [sheet_rows, f"ID_{applicant_id[i]}", None, degree[i], nationality[i], name[i],
                    interest[i], None, bs_gpa[i], ms_gpa[i], gre[i], toefl[i], gender[i], None, None, None]
            AutoRunner.test_test_parser(output)

        return output

    @staticmethod
    def test_test_parser(info):
        print(info)
        if info[1] == "ID_1000":
            print("When I find applicant_id 1000,")
            test1 = True
            if info[5] == "Ryuki":
                print("I should see 'Ryuki'")
                print("name test passed")
            else:
                test1 = False
                print("name test didn't pass")
            if info[3] == "MS":
                print("I should see 'MS'")
                print("degree test passed")
            else:
                test1 = False
                print("degree test didn't pass")
            if info[4] == "JAPAN":
                print("I should see 'JAPAN'")
                print("nationality test passed")
            else:
                test1 = False
                print("nationality test didn't pass")
            if test1:
                print("=> test 1 passed!")
            else:
                print("=> test 1 didn't pass")
        elif info[1] == "ID_1100":
            print("When I find applicant_id 1100,")
            test2 = True
            if info[5] == "Kobayashi":
                print("I should see 'Kobayashi'")
                print("name test passed")
            else:
                test2 = False
                print("name test didn't pass")
            if info[11] == 110:
                print("I should see 110")
                print("toefl test passed")
            else:
                test2 = False
                print("toefl test didn't pass")
            if info[8] == 3.5:
                print("I should see 3.5")
                print("bs_gpa test passed")
            else:
                test2 = False
                print("bs_gpa test didn't pass")
            if test2:
                print("=> test 2 passed!")
            else:
                print("=> test 2 didn't pass")
    @staticmethod
    def test_pdf(path):
        with open(path, "r") as f:
            processed_names = list(set(f.read().split("\n")))
        print("When I see pdf files....")
        print(processed_names)
        if "Davis_629_Fall2020_HW2_solution.pdf" in processed_names:
            print("I should see Davis_629_Fall2020_HW2_solution.pdf in line 1")
            print("case 1 test passed!")
        else:
            print("case 1 test didn't pass")
        if "Davis_629_Fall2020_HW2_solution.pdf" in processed_names:
            print("I should see Davis_629_Fall2020_HW1_solution.pdf in line 2")
            print("case 2 test passed!")
        else:
            print("case 2 test didn't pass")

    def parse_new_pdfs(self):
        """
        Step3: Parse the new pdfs and store the new information to the processed_txt
            Update the info txt file, this file contains all phd info, just like a google sheet
        """
        print("#####", self.name_id_dict)
        if not self.name_id_dict:
            return
        self.new_data = []
        for file_path in self.name_id_dict:
            self.sheet_rows += 1
            new_file_path = os.path.join(LOCAL_PROCESSED_TXT_DIR, get_filename(file_path)[:-3]+"txt")
            self.new_data.append(self.test_parser(self.sheet_rows, file_path))
            new_line = ",".join([str(_) for _ in self.new_data[-1]])
            new_line += "\n"
            with open(new_file_path, "w") as f:
                f.write(new_line)
            with open(self.local_applicants_info_file_path, "a") as f:
                f.write(new_line)

    def upload_logfile_and_infofile(self):
        """
        Step4: Delete the old log file and  upload the new log file to the google drive.
        """
        if not self.name_id_dict:
            return
        print("log_file_id is {0}".format(self.log_file_id))
        if self.log_file_id is not None:
            self.drive_service.files().delete(fileId=self.log_file_id).execute()
        demo_upload_file_to_google_drive(self.drive_service, file_paths=[self.local_log_file_path], folder_id=self.pdf_folder_id)

        print("info_file_id is {0}".format(self.applicants_info_file_id))
        if self.applicants_info_file_id is not None:
            self.drive_service.files().delete(fileId=self.applicants_info_file_id).execute()
        demo_upload_file_to_google_drive(self.drive_service, file_paths=[self.local_applicants_info_file_path], folder_id=self.txt_folder_id)
        """
        Step5: Upload the new processed txts to google drive for backup
        """
        processed_txt_file_paths = [os.path.join(LOCAL_PROCESSED_TXT_DIR, get_filename(_)[:-3] + "txt") for _ in self.name_id_dict]
        demo_upload_file_to_google_drive(self.drive_service, file_paths=processed_txt_file_paths, folder_id=self.txt_folder_id)

    def update_google_sheet(self):
        """
        Step6: Update the new info to the google sheet
        """
        if not self.name_id_dict:
            return
        demo_update_google_sheet(self.sheet_service, data_list=self.new_data)

    def run(self):
        self.load_google_drive_items()
        self.download_logfile_and_infofile()
        self.download_new_pdfs()
        AutoRunner.test_parser(0, "")

        if self.name_id_dict:
            self.parse_new_pdfs()
            self.upload_logfile_and_infofile()
            self.update_google_sheet()
        else:
            print(f"{datetime.datetime.now()}: No new pdfs")

if __name__ == "__main__":
    while True:
        AutoRunner().run()
        time.sleep(10)
