1. To install the required packages: 
	pip install --upgrade google-api-python-client google-auth-httplib2 google-auth-oauthlib

2. I created a google account for testing
	account:  aihua.xu123
	password: jjj123456
   Also a test google sheet, it is in the google drive of the test account:
 	https://docs.google.com/spreadsheets/d/1yV7XHAy17Isg5boaf2tEvzpqcKdr9-m-sqYt2CsPeNs/edit#gid=0

3. Four demo programs:
	demo_google_drive_list_files.py   : this program will list all files in the google drive
	demo_google_drive_upload_files.py : this program will upload specified files in your local pc
	demo_google_sheet_list_values.py  : this program will list data values in the test google sheet
	demo_google_sheet_append_data.py  : this program will append a new row to the test sheet
   One demo program includes the whole process:
	demo_work_flow.py
	(1) python demo_work_flow.py
	(2) upload some pdf files in the raw_pdf directory in the above google drive
	(3) the program will download the pdfs and parse them use a random_parser (just for demo), the parser
	    will return a list of random values as new parsed data.
	(4) then it will upload those parsed data into the processed_txt directory in the google drive
	(5) open the test google sheet, the new parsed information should be already appended

4. For 1st time login, an authentication page may be prompted, fill in your google account and password
   Currently, we are using the cached authentication file in the token directory, if it is not expired, 
   the program will connects to the test drive and test sheet directly.

!!! whenever modify the google_drive_access_scopes in config.json, (for testing, there is no need to change the scopes now), for example, modify the access allowed to google drive or google sheet,
should delete the cached_auth_file, in order to update the permissions.
