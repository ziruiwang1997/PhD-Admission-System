from utils import (
    GoogleServiceConnector,
    get_google_sheet_service,
    demo_list_values_in_google_sheet
)

def main():
	conn = GoogleServiceConnector()
	conn.connect()
	sheet_service = get_google_sheet_service(conn)
	demo_list_values_in_google_sheet(sheet_service)

if __name__ == "__main__":
    main()
