from utils import (
    GoogleServiceConnector,
    get_google_sheet_service,
    demo_update_google_sheet
)

def main():
	conn = GoogleServiceConnector()
	conn.connect()
	sheet_service = get_google_sheet_service(conn)
	data_list = [[6, "petter", 1.0], [7, "jackson", 3.5]]
	demo_update_google_sheet(sheet_service, data_list=data_list)

if __name__ == '__main__':
    main()
