from constants import CONFIG, SHEET_ID, SHEET_RANGE
from googleapiclient import discovery
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.http import (
    MediaIoBaseDownload,
    MediaFileUpload
)
import io
import json
import os
import pickle
from pprint import pprint


class GoogleServiceConnector:
    def __init__(self, config_file=CONFIG):
        self.config_file = config_file
        self.config = None
        self.auth_info = None

    def load_config(self):
        with open(self.config_file, "rb") as f:
            self.config = json.load(f)

    def connect(self):
        if self.config is None:
            self.load_config()
        self.auth_info = authentication(self.config)
    
    def get_auth_info(self):
        return self.auth_info

def get_google_drive_service(conn):
    service = discovery.build("drive", "v3", credentials=conn.get_auth_info())
    return service

def get_google_sheet_service(conn):
    service = discovery.build("sheets", "v4", credentials=conn.get_auth_info())
    return service

def load_cached_auth_file(file_name):
    with open(file_name, "rb") as f:
        auth_info = pickle.load(f)
        return auth_info

def save_cached_auth_file(auth_info, file_name):
    with open(file_name, "wb") as f:
        pickle.dump(auth_info, f)

def authentication(config):
    auth_info = None
    auth_file = config["auth_file"]
    cached_auth_file = config["cached_auth_file"]
    google_drive_access_scopes = config["google_drive_access_scopes"]
    default_port_number = config["default_port_number"]
    if os.path.exists(cached_auth_file):
        auth_info = load_cached_auth_file(cached_auth_file)
    if (auth_info is None) or (not auth_info.valid):
        if auth_info is not None and auth_info.expired and auth_info.refresh_token:
            auth_info.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(auth_file, google_drive_access_scopes)
            auth_info = flow.run_local_server(port=default_port_number)
        # cache auth_info
        save_cached_auth_file(auth_info, cached_auth_file)
    return auth_info

def demo_list_files_in_google_drive_whole(service, page_size=20):
    results = service.files().list(pageSize=page_size, fields="nextPageToken, files(id, name)").execute()
    items = results.get("files", [])
    print("FileName\t\t\tFileID")
    for item in items:
        if item["name"].endswith(".pdf"):
            print("{0:30}\t{1}".format(item["name"], item["id"]))    

def demo_list_files_in_google_drive(service, folder_id=None):
    if folder_id is not None:
        # excluding files in trash
        results = service.files().list(q=f"'{folder_id}' in parents and trashed=false", fields="nextPageToken, files(id, name)").execute()
        # including files in trash
        # results = service.files().list(q=f"'{folder_id}' in parents", fields="nextPageToken, files(id, name)").execute()
    else:
        results = service.files().list(q=f"trashed=false", fields="nextPageToken, files(id, name)").execute()
        # results = service.files().list(fields="nextPageToken, files(id, name)").execute()
    items = results.get("files", [])
    print("FileName\t\t\tFileID")
    for item in items:
        print("{0:30}\t{1}".format(item["name"], item["id"]))  

def get_google_sheet_rows(service, sheet_id=SHEET_ID, sheet_range=SHEET_RANGE):
    sheet = service.spreadsheets()
    result = sheet.values().get(spreadsheetId=sheet_id, range=sheet_range).execute()
    return len(result.get("values"))

def demo_list_values_in_google_sheet(service, sheet_id=SHEET_ID, sheet_range=SHEET_RANGE):
    sheet = service.spreadsheets()
    result = sheet.values().get(spreadsheetId=sheet_id, range=sheet_range).execute()
    values = result.get("values", [])
    for row in values:
        print("{0}\t{1}\t{2}".format(row[0], row[1], row[2]))

def demo_download_file_from_google_drive(service, name_id_dict):
    for file_name, file_id in name_id_dict.items():
        request = service.files().get_media(fileId=file_id)
        fh = io.BytesIO()
        downloader = MediaIoBaseDownload(fd=fh, request=request)
        done = False
        print("{0} Downloading file: {1}".format("-"*5, file_name))
        while not done:
            status, done = downloader.next_chunk()
        fh.seek(0)
        with open(file_name, "wb") as f:
            f.write(fh.read())
        print(f"\tSucessfully downloaded file: {file_name}")

def demo_upload_file_to_google_drive(service, file_paths, folder_id):
    file_metadata = { "parents" : [folder_id] }
    for file_path in file_paths:
        file_name = get_filename(file_path)
        file_metadata["name"] = file_name
        media = MediaFileUpload(file_path)
        print("{0} Uploading file: {1}".format("-"*5, file_name))
        service.files().create(body=file_metadata, media_body=media, fields="id").execute()
        print(f"\tSucessfully downloaded file: {file_name}")

def demo_upload_file_to_google_drive_specify_mimtypes_folders(service, file_zip):
    for file_path, mime_type, folder_id in file_zip:
        file_name = get_filename(file_path)
        file_metadata = {
            "name" : file_name,
            "parents" : [folder_id]
        }
        media = MediaFileUpload(file_path, mimetype=mime_type)
        print("{0}Uploading file: {1}".format("-"*10, file_name))
        service.files().create(body=file_metadata, media_body=media, fields="id").execute()
        print(f"\tSucessfully downloaded file: {file_name}")

def get_filename(file_path):
    return os.path.basename(file_path)
    
# append data
def demo_update_google_sheet(service, sheet_id=SHEET_ID, sheet_range=SHEET_RANGE, data_list=None):
    if not data_list:
        return
    print("{0} Updating Google Sheet".format("-"*5))
    print("\tThe following data are going to be appended to your google sheet: ")
    print(data_list)
    body = {
        "majorDimension" : "ROWS",
        "values" : data_list
    }
    request = service.spreadsheets().values().append(
        spreadsheetId=sheet_id, 
        range=sheet_range,
        body=body,
        valueInputOption="USER_ENTERED"
    )
    response = request.execute()
    print("\tThe following updates are successfully processed!")
    pprint(response)

def load_config(config_file=CONFIG):
    with open(config_file, "rb") as f:
        config = json.load(f)
        return config