import time
from work_flow import AutoRunner

if __name__ == "__main__":
    while True:
    	AutoRunner().run()
    	time.sleep(30)