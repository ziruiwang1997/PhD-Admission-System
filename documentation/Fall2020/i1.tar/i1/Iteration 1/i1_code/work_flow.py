from constants import (
    LOCAL_RAW_PDF_DIR,
    LOCAL_PROCESSED_TXT_DIR,
    DRIVE_RAW_PDF_DIR, 
    DRIVE_PROCESSED_TXT_DIR,
    DRIVE_FOLDER_ID_DICT,
    LOG_FILE_NAME,
    APPLICANTS_INFO_FILE_NAME
)
import os
import random
import datetime
import time
from utils import (
    GoogleServiceConnector,
    get_google_drive_service,
    get_google_sheet_service,
    demo_download_file_from_google_drive,
    demo_upload_file_to_google_drive,
    demo_update_google_sheet,
    get_filename,
    get_google_sheet_rows
)

class AutoRunner:
    pdf_folder_id = DRIVE_FOLDER_ID_DICT[DRIVE_RAW_PDF_DIR]
    txt_folder_id = DRIVE_FOLDER_ID_DICT[DRIVE_PROCESSED_TXT_DIR]
    local_log_file_path = os.path.join(LOCAL_RAW_PDF_DIR, LOG_FILE_NAME)
    local_applicants_info_file_path = os.path.join(LOCAL_PROCESSED_TXT_DIR, APPLICANTS_INFO_FILE_NAME)
    
    @staticmethod
    def create_directory(directory):
        if not os.path.exists(directory):
        	os.mkdir(directory)
    
    @staticmethod
    def create_file(file_path):
        with open(file_path, "w") as f:
            pass
    
    def __init__(self):
        self.create_directory(LOCAL_PROCESSED_TXT_DIR)
        self.create_directory(LOCAL_RAW_PDF_DIR)
        conn = GoogleServiceConnector()
        conn.connect()
        self.drive_service = get_google_drive_service(conn)
        self.sheet_service = get_google_sheet_service(conn)
        self.sheet_rows = get_google_sheet_rows(self.sheet_service) - 1
        
    def load_google_drive_items(self):
        """
        Step1: Scan the raw_pdf directory in google drive, check whether there are new pdfs
            the 'log.txt' file in the directory contains processed pdfs, we only need to download 
            those files not listed in 'log.txt'.
        """
        results = self.drive_service.files().list(q=f"'{self.pdf_folder_id}' in parents and trashed=false", fields="nextPageToken, files(id, name)").execute()
        self.pdf_dir_items = results.get("files", [])
        results = self.drive_service.files().list(q=f"'{self.txt_folder_id}' in parents and trashed=false", fields="nextPageToken, files(id, name)").execute()
        self.txt_dir_items = results.get("files", [])
        
    def download_logfile_and_infofile(self):
        self.log_file_id = None
        self.applicants_info_file_id = None
        for item in self.pdf_dir_items:
            if item["name"].endswith(LOG_FILE_NAME):
                self.log_file_id = item["id"]
                demo_download_file_from_google_drive(self.drive_service, {self.local_log_file_path : self.log_file_id})
                break
        if self.log_file_id is None:
            self.create_file(self.local_log_file_path)
        
        for item in self.txt_dir_items:
            if item["name"].endswith(APPLICANTS_INFO_FILE_NAME):
                self.applicants_info_file_id = item["id"]
                demo_download_file_from_google_drive(self.drive_service, {self.local_applicants_info_file_path : self.applicants_info_file_id})
                break
        if self.applicants_info_file_id is None:
            self.create_file(self.local_applicants_info_file_path)
    
    def download_new_pdfs(self):
        """
        Step2: Download those new pdfs and the log file
            Store them in the local raw_pdf directory 
        """
        # download pdfs
        self.name_id_dict = dict()
        with open(self.local_log_file_path, "r") as f:
            processed_names = set(f.read().split("\n"))
        
        with open(self.local_log_file_path, "a") as f:
            for item in self.pdf_dir_items:
                name = item["name"]
                if name.endswith(".pdf") and name not in processed_names:
                    self.name_id_dict[os.path.join(LOCAL_RAW_PDF_DIR, name)] = item["id"]
                    f.write(f"{name}\n")
        if self.name_id_dict:
            demo_download_file_from_google_drive(self.drive_service, self.name_id_dict)
    
    @staticmethod
    def test_parser(sheet_rows, file_path):
        degrees = ["MS", "PHD", "BS"]
        nationalities = ["USA", "UK", "CHINA", "INDIA", "JAPAN", "CANADA"]
        names = ["Jack", "Tom", "Micheal", "Jackson", "Tommy", "Allen", "James"]
        interests = ["SE", "AI", "DL", "ME", "ECON", "FINTECH", "MATH", "PHYSICS"]
        genders = ['F', 'M']
        applicant_id = random.randint(1, 10000)
        name = random.choice(names) + ", " + random.choice(names)
        degree = random.choice(degrees)
        nationality = random.choice(nationalities)
        interest = random.choice(interests)
        bs_gpa = random.uniform(1, 5)
        ms_gpa = random.uniform(1, 5)
        gre = random.randint(320, 340)
        toefl = random.randint(100, 120)
        gender = random.choice(genders)
        applicant_gpa = random.uniform(0, 5)
        
        return [sheet_rows, f"ID_{applicant_id}", None, None, degree, nationality, name, 
                interest, None, bs_gpa, ms_gpa, gre, toefl, gender, None, None, None]
        
    def parse_new_pdfs(self):
        """
        Step3: Parse the new pdfs and store the new information to the processed_txt
            Update the info txt file, this file contains all phd info, just like a google sheet
        """
        if not self.name_id_dict:
            return
        self.new_data = []
        for file_path in self.name_id_dict:
            self.sheet_rows += 1
            new_file_path = os.path.join(LOCAL_PROCESSED_TXT_DIR, get_filename(file_path)[:-3]+"txt")
            self.new_data.append(self.test_parser(self.sheet_rows, file_path))
            new_line = ";".join([str(_) for _ in self.new_data[-1]])
            new_line += "\n"
            with open(new_file_path, "w") as f:
                f.write(new_line)
            with open(self.local_applicants_info_file_path, "a") as f:
                f.write(new_line)
                
    def upload_logfile_and_infofile(self):
        """
        Step4: Delete the old log file and  upload the new log file to the google drive.
        """
        if not self.name_id_dict:
            return
        print("log_file_id is {0}".format(self.log_file_id))
        if self.log_file_id is not None:
            self.drive_service.files().delete(fileId=self.log_file_id).execute()
        demo_upload_file_to_google_drive(self.drive_service, file_paths=[self.local_log_file_path], folder_id=self.pdf_folder_id)
        
        print("info_file_id is {0}".format(self.applicants_info_file_id))
        if self.applicants_info_file_id is not None:
            self.drive_service.files().delete(fileId=self.applicants_info_file_id).execute()
        demo_upload_file_to_google_drive(self.drive_service, file_paths=[self.local_applicants_info_file_path], folder_id=self.txt_folder_id)
        """
        Step5: Upload the new processed txts to google drive for backup
        """
        processed_txt_file_paths = [os.path.join(LOCAL_PROCESSED_TXT_DIR, get_filename(_)[:-3] + "txt") for _ in self.name_id_dict]
        demo_upload_file_to_google_drive(self.drive_service, file_paths=processed_txt_file_paths, folder_id=self.txt_folder_id)
    
    def update_google_sheet(self):
        """
        Step6: Update the new info to the google sheet
        """
        if not self.name_id_dict:
            return
        demo_update_google_sheet(self.sheet_service, data_list=self.new_data)

    def run(self):
        self.load_google_drive_items()
        self.download_logfile_and_infofile()
        self.download_new_pdfs()
        if self.name_id_dict:
            self.parse_new_pdfs()
            self.upload_logfile_and_infofile()
            self.update_google_sheet()
        else:
            print(f"{datetime.datetime.now()}: No new pdfs")
        
if __name__ == "__main__":
    while True:
        AutoRunner().run()
        time.sleep(60)
        